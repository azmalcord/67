# BusterNodes Unified Discord Bot

A single Discord.js bot project combining music, tickets, moderation tools, AI assistance, AI auto-moderation/watch, summaries, XP leveling and role rewards, polls, giveaways, suggestions, staff applications, feedback, QR payments, database backup, and a web dashboard.

## Requirements

- Node.js 22.12 or newer (recommended for the current Discord.js/music dependencies).
- A Discord bot application and bot token.
- FamGateway merchant API key only if using `/payment`.
- An OpenAI-compatible AI API key only if using AI commands / AI safety modules.

## Install on Plugged Host / Pterodactyl-style panel

1. Upload and extract this ZIP so `package.json` and `index.js` are at the server's root (not one folder deeper).
2. Copy `.env.example` to `.env` locally or add the equivalent variables in the hosting panel's environment/startup variables. Never upload a real `.env` publicly.
3. Set `DISCORD_TOKEN` and `CLIENT_ID`. Set `GUILD_ID` to your test server for instant guild command updates; leave it blank for global commands.
4. Run `npm install`, then `npm run deploy`, then `npm start`. The bot's main file is `index.js`.
5. For the web dashboard, run `npm run panel` in a separate process/second server allocation if your host supports it. Set `DASHBOARD_PORT`, `DASHBOARD_USER`, `DASHBOARD_PASSWORD`, and a long random `DASHBOARD_SESSION_SECRET`. Do not expose the dashboard with its example password.
6. In Discord Developer Portal, enable **Message Content Intent** for the AI chat/message watch, prefix commands, anti-spam, invite link detection, and XP listeners. Invite with `bot` and `applications.commands` scopes, plus the permissions required by enabled modules. Keep the bot role above level-reward roles.

The provided startup command from a typical Node panel can use `MAIN_FILE=index.js`. Ensure the panel uses Node 22 or newer and preserves the `data/` directory across restarts.

## Slash commands

- `/ticket-panel`, `/ticket-config` — private support ticket panel and categories.
- `/feedback`, `/notes`, `/mod`, `/clear`, `/lock`, `/unlock`, `/ai`, `/ai-msg`, `/msg` — feedback, notes, moderation, and assistant utilities.
- `/rank`, `/leaderboard`, `/level-role` — XP rankings and level-based role rewards.
- `/security-config`, `/watch`, `/chat-summary` — protection toggles, AI staff-review reports, and AI chat summaries.
- `/poll`, `/giveaway`, `/spin`, `/suggest`, `/staff-apply` — community engagement.
- `/payment`, `/payment-status` — FamGateway orders and server-side payment verification.
- `/bot-health`, `/backup` — diagnostic summary and private SQLite export.
- Existing music commands (`/play`, `/queue`, `/skip`, `/lyrics`, etc.) are retained from the base project.

## AI provider configuration

Set `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL`. For an OpenAI-compatible provider use its official base URL and model ID. Never hard-code API keys into source code. Start with `automod` disabled; enable it only after configuring `MOD_LOG_CHANNEL_ID` and reviewing results. AI classification is deliberately conservative and should not replace staff judgment.

## FamGateway configuration

Set `FAMGATEWAY_API_KEY` in the server environment. The bot calls `POST https://famgateway.in/api/create-order` and the authenticated server verification endpoint. If you want webhook callbacks, set `PUBLIC_BASE_URL` to a publicly reachable HTTPS dashboard URL and configure the same path (`/api/famgateway-webhook`) in FamGateway merchant settings. The webhook checks the HMAC-SHA256 signature against the exact raw JSON body using the merchant API key. Confirmed success is matched against the bot's stored order and amount before any reward role is assigned. Role fulfillment is optional via `PAYMENT_REWARD_ROLE_ID`.

Payment QR sessions expire in approximately five minutes according to the provided FamGateway API documentation. This bot never treats a client-side redirect as proof of payment.

## Dashboard

The dashboard uses HTTP Basic-like session login with `DASHBOARD_USER` / `DASHBOARD_PASSWORD` and provides ticket, feedback, application, payment, and per-guild security views. For internet exposure, use HTTPS via a reverse proxy/tunnel and change the example password and session secret first.

## Data and backups

SQLite data is stored at `data/busternodes.sqlite`. `/backup` sends a private database attachment to an administrator; treat the file as confidential. Keep an offline backup before upgrades.

## Security module defaults

Anti-spam and invite protection default to enabled; XP also defaults to enabled. AI auto-moderation, AI Chat Watch, and anti-nuke are opt-in per guild. Configure logging using `MOD_LOG_CHANNEL_ID` or `TICKET_LOG_CHANNEL_ID`. Anti-nuke can remove manageable roles after repeated high-impact audit events; test permissions in a private server before enabling it.

## Verification status

Source files are syntax-checked in the build environment. A live Discord login, FamGateway transaction, and production dashboard deployment require your Discord token, API credentials, and hosting environment, so those cannot be verified from this ZIP alone.
