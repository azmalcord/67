'use strict';
const {spawn}=require('node:child_process');
const children=[spawn(process.execPath,['index.js'],{stdio:'inherit',env:process.env}),spawn(process.execPath,['dashboard.js'],{stdio:'inherit',env:process.env})];
for(const child of children)child.on('exit',(code)=>{if(code&&code!==0)console.error(`Process exited with code ${code}`)});
function stop(){for(const child of children)child.kill('SIGTERM');}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
