# Installation on a Node.js hosting panel

1. Upload `BusterNodes-Unified-Bot-Complete.zip` and extract it. Confirm that `package.json`, `index.js`, `.env.example`, `src/`, and `dashboard.js` are at the server root.
2. Select Node.js 22.12+. The startup main file is `index.js`.
3. In startup/environment variables, provide `DISCORD_TOKEN`, `CLIENT_ID`; optionally `GUILD_ID` for a test guild. Set credentials per `.env.example` only for modules you plan to use.
4. Install dependencies: `npm install`.
5. Register Discord slash commands: `npm run deploy`.
6. Start the bot: `npm start`.
7. Dashboard is a separate process: `npm run panel`, using a second allocation/server if the panel doesn't support two processes. Set a strong dashboard password and session secret before exposing it.

## Discord setup

Enable Message Content Intent in Discord Developer Portal for XP, anti-spam, invite protection, prefix commands, and AI message analysis. Give the bot only needed permissions: View Channels, Send Messages, Read Message History, Manage Messages, Moderate Members, Manage Channels, Manage Roles, and View Audit Log as required by features. Place its role above any roles it needs to assign/remove.

## Hosting variables for modules

- AI: `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`.
- Tickets: `TICKET_CATEGORY_ID`, `TICKET_STAFF_ROLE_ID`, `TICKET_LOG_CHANNEL_ID`.
- Safety logs: `MOD_LOG_CHANNEL_ID`.
- Staff applications: `APPLICATIONS_CHANNEL_ID`.
- Suggestions: `SUGGESTIONS_CHANNEL_ID`.
- Feedback: `FEEDBACK_CHANNEL_ID`, optional `FEEDBACK_IMAGE_URL`.
- Payments: `FAMGATEWAY_API_KEY`, optional `PUBLIC_BASE_URL` (HTTPS), `PAYMENT_REWARD_ROLE_ID`, `PAYMENT_LOG_CHANNEL_ID`.

Never paste real bot tokens or gateway keys into public messages, source code repositories, or browser-facing configuration.
