'use strict';
const { SlashCommandBuilder, ChannelType } = require('discord.js');
const settings = require('../core/guild-settings');
const views = require('../ui/views');
module.exports = {
  category: 'settings',
  data: new SlashCommandBuilder().setName('247').setDescription('Keep the bot connected to a music voice channel 24/7').setContexts(0).setDefaultMemberPermissions(null)
    .addChannelOption(o => o.setName('musicchnlname').setDescription('Voice channel to stay in').addChannelTypes(ChannelType.GuildVoice).setRequired(true)),
  async execute(interaction, { manager }) {
    if (!settings.isModerator(interaction)) return interaction.reply(views.notice('Only administrators or moderators can configure 24/7 mode.'));
    const channel = interaction.options.getChannel('musicchnlname', true);
    const permissions = channel.permissionsFor(interaction.guild.members.me);
    if (!permissions?.has(['ViewChannel', 'Connect', 'Speak'])) return interaction.reply(views.notice('I need View Channel, Connect, and Speak permissions in that voice channel.'));
    await settings.update(interaction.guildId, { channel247: channel.id });
    try {
      await manager.distube.voices.join(channel);
      return interaction.reply(views.notice(`24/7 mode enabled for <#${channel.id}>. I will stay connected when the queue is empty.`));
    } catch (error) {
      await settings.update(interaction.guildId, { channel247: null });
      return interaction.reply(views.notice(`Could not join that voice channel: ${error.message}`));
    }
  }
};
