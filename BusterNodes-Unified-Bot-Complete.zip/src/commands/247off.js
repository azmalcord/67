'use strict';
const { SlashCommandBuilder } = require('discord.js');
const settings = require('../core/guild-settings');
const views = require('../ui/views');
module.exports = {
  category: 'settings',
  data: new SlashCommandBuilder().setName('247off').setDescription('Disable 24/7 voice connection').setContexts(0).setDefaultMemberPermissions(null),
  async execute(interaction, { manager }) {
    if (!settings.isModerator(interaction)) return interaction.reply(views.notice('Only administrators or moderators can disable 24/7 mode.'));
    await settings.update(interaction.guildId, { channel247: null });
    manager.distube.voices.leave(interaction.guildId);
    return interaction.reply(views.notice('24/7 mode disabled.'));
  }
};
