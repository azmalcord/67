'use strict';
const { SlashCommandBuilder } = require('discord.js');
const settings = require('../core/guild-settings');
const views = require('../ui/views');
module.exports = {
  category: 'settings',
  data: new SlashCommandBuilder().setName('public').setDescription('Enable or disable public music commands').setContexts(0).setDefaultMemberPermissions(null)
    .addBooleanOption(o => o.setName('enabled').setDescription('True: everyone can use music commands; false: only approved users and moderators').setRequired(true)),
  async execute(interaction) {
    if (!settings.isModerator(interaction)) return interaction.reply(views.notice('Only administrators or moderators can change this setting.'));
    const enabled = interaction.options.getBoolean('enabled', true);
    await settings.update(interaction.guildId, { public: enabled });
    return interaction.reply(views.notice(enabled ? 'Public mode enabled. Everyone can use music commands.' : 'Public mode disabled. Only the two approved user IDs and moderators can use music commands.'));
  }
};
