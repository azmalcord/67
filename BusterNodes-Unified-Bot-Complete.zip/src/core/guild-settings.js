'use strict';
const path = require('node:path');
const config = require('../config');
const { JsonStore } = require('./store');
const store = new JsonStore(path.join(config.dataDir, 'guild-settings'));
const ALLOWED_PRIVATE_USERS = new Set(['1438804058164166760', '1353572110592643076']);
function get(guildId) { return store.get(guildId) || { public: false, channel247: null }; }
async function update(guildId, patch) { return store.set(guildId, { ...get(guildId), ...patch }); }
function isModerator(interaction) {
  const p = interaction.memberPermissions;
  return Boolean(p?.has('Administrator') || p?.has('ManageGuild') || p?.has('ManageMessages'));
}
function canUseMusic(interaction) {
  if (isModerator(interaction)) return true;
  const settings = get(interaction.guildId);
  return settings.public || ALLOWED_PRIVATE_USERS.has(interaction.user.id);
}
module.exports = { get, update, isModerator, canUseMusic, ALLOWED_PRIVATE_USERS };
