'use strict';
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db=require('./db');
const data=new SlashCommandBuilder().setName('notes').setDescription('Manage your private BusterNotes')
 .addSubcommand(s=>s.setName('add').setDescription('Save a personal note').addStringOption(o=>o.setName('title').setDescription('Note title').setRequired(true).setMaxLength(80)).addStringOption(o=>o.setName('text').setDescription('Note content').setRequired(true).setMaxLength(1800)))
 .addSubcommand(s=>s.setName('list').setDescription('List your saved notes'))
 .addSubcommand(s=>s.setName('read').setDescription('Read a note').addIntegerOption(o=>o.setName('id').setDescription('Note ID').setRequired(true).setMinValue(1)))
 .addSubcommand(s=>s.setName('delete').setDescription('Delete a note').addIntegerOption(o=>o.setName('id').setDescription('Note ID').setRequired(true).setMinValue(1)));
async function execute(i) {
 const sub=i.options.getSubcommand(), uid=i.user.id;
 if(sub==='add'){const r=db.prepare('INSERT INTO notes(user_id,title,body) VALUES(?,?,?)').run(uid,i.options.getString('title'),i.options.getString('text'));return i.reply({content:`Saved private note #${r.lastInsertRowid}.`,ephemeral:true});}
 if(sub==='list'){const rows=db.prepare('SELECT id,title,created_at FROM notes WHERE user_id=? ORDER BY id DESC LIMIT 20').all(uid);const desc=rows.length?rows.map(n=>`**#${n.id}** — ${n.title}`).join('\n'):'No notes yet. Use `/notes add` to save one.';return i.reply({embeds:[new EmbedBuilder().setColor(0x7b2437).setTitle('Your BusterNotes').setDescription(desc)],ephemeral:true});}
 const id=i.options.getInteger('id'), note=db.prepare('SELECT * FROM notes WHERE id=? AND user_id=?').get(id,uid);
 if(!note)return i.reply({content:'Note not found. Notes are private to their owner.',ephemeral:true});
 if(sub==='read')return i.reply({embeds:[new EmbedBuilder().setColor(0x7b2437).setTitle(note.title).setDescription(note.body).setFooter({text:`Private note #${note.id}`})],ephemeral:true});
 db.prepare('DELETE FROM notes WHERE id=? AND user_id=?').run(id,uid);return i.reply({content:`Deleted note #${id}.`,ephemeral:true});
}
module.exports={category:'notes',data,execute};
