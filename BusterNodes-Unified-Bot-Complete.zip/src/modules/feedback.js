'use strict';
const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const db = require('./db');

const data = new SlashCommandBuilder()
 .setName('feedback')
 .setDescription('Rate BusterNodes and optionally leave a review');

async function execute(interaction) {
 const modal = new ModalBuilder()
  .setCustomId('bn_feedback_modal')
  .setTitle('BusterNodes Feedback');

 const rating = new TextInputBuilder()
  .setCustomId('rating')
  .setLabel('Rating (1-10)')
  .setPlaceholder('Enter a number from 1 to 10')
  .setStyle(TextInputStyle.Short)
  .setMinLength(1)
  .setMaxLength(2)
  .setRequired(true);

 const review = new TextInputBuilder()
  .setCustomId('review')
  .setLabel('Message (optional)')
  .setPlaceholder('Tell us about your experience')
  .setStyle(TextInputStyle.Paragraph)
  .setMaxLength(1000)
  .setRequired(false);

 modal.addComponents(
  new ActionRowBuilder().addComponents(rating),
  new ActionRowBuilder().addComponents(review)
 );
 return interaction.showModal(modal);
}

async function submit(interaction) {
 const raw = interaction.fields.getTextInputValue('rating').trim();
 const rating = Number(raw);

 if (!Number.isInteger(rating) || rating < 1 || rating > 10) {
  return interaction.reply({
   content: 'Rating must be a whole number from 1 to 10.',
   ephemeral: true
  });
 }

 const review = interaction.fields.getTextInputValue('review').trim();
 db.prepare('INSERT INTO feedback(guild_id,user_id,rating,review) VALUES(?,?,?,?)')
  .run(interaction.guildId, interaction.user.id, rating, review);

 // Match the compact feedback-card style: title, rating, message, user, banner, timestamp.
 const stars = '★'.repeat(Math.ceil(rating / 2));
 const embed = new EmbedBuilder()
  .setColor(process.env.FEEDBACK_EMBED_COLOR || '#18D890')
  .setTitle('New Feedback')
  .setDescription(
   `**Rating:** ${stars} ${rating}/10\n\n` +
   `**Message:** ${review ? review : '*No message provided*'}\n\n` +
   `**User**\n<@${interaction.user.id}>`
  )
  .setTimestamp();

 const imageUrl = process.env.FEEDBACK_IMAGE_URL?.trim();
 if (imageUrl) embed.setImage(imageUrl);

 const channelId = process.env.FEEDBACK_CHANNEL_ID;
 const channel = channelId
  ? await interaction.guild.channels.fetch(channelId).catch(() => null)
  : interaction.channel;

 if (channel?.isTextBased()) {
  await channel.send({
   embeds: [embed],
   allowedMentions: { parse: [] }
  });
 }

 return interaction.reply({
  content: 'Thanks! Your feedback has been submitted.',
  ephemeral: true
 });
}

module.exports = { category: 'feedback', data, execute, submit };
