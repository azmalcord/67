'use strict';
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder }=require('discord.js');
const db=require('./db');
const config=require('../config');
const data=new SlashCommandBuilder().setName('mod').setDescription('Moderation tools')
 .addSubcommand(s=>s.setName('warn').setDescription('Warn a member').addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(true).setMaxLength(500)))
 .addSubcommand(s=>s.setName('timeout').setDescription('Timeout a member').addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('Duration in minutes').setRequired(true).setMinValue(1).setMaxValue(40320)).addStringOption(o=>o.setName('reason').setDescription('Reason').setMaxLength(500)))
 .addSubcommand(s=>s.setName('ban').setDescription('Ban a member').addUserOption(o=>o.setName('member').setDescription('Member').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason').setMaxLength(500)));
async function execute(i){
 if(!i.memberPermissions?.has(PermissionFlagsBits.ModerateMembers) && !i.memberPermissions?.has(PermissionFlagsBits.BanMembers)) return i.reply({content:'You need the relevant moderation permission.',ephemeral:true});
 const sub=i.options.getSubcommand(), user=i.options.getUser('member'), reason=i.options.getString('reason')||'No reason provided';
 const member=await i.guild.members.fetch(user.id).catch(()=>null);
 if(!member)return i.reply({content:'That member is not in this server.',ephemeral:true});
 if(user.id===i.user.id||user.id===i.client.user.id)return i.reply({content:'You cannot moderate yourself or the bot.',ephemeral:true});
 if(sub==='warn'){
  db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(i.guildId,i.user.id,user.id,'warn',reason);
  await user.send(`You were warned in ${i.guild.name}. Reason: ${reason}`).catch(()=>{});
  return i.reply({embeds:[new EmbedBuilder().setColor(config.bot.color).setTitle('Member warned').setDescription(`${user} was warned.\n**Reason:** ${reason}`)]});
 }
 if(sub==='timeout'){
  if(!i.memberPermissions.has(PermissionFlagsBits.ModerateMembers))return i.reply({content:'You need Moderate Members permission.',ephemeral:true});
  const minutes=i.options.getInteger('minutes');await member.timeout(minutes*60000,reason);
  db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(i.guildId,i.user.id,user.id,'timeout',`${minutes}m: ${reason}`);
  return i.reply({content:`Timed out ${user} for ${minutes} minutes. Reason: ${reason}`});
 }
 if(!i.memberPermissions.has(PermissionFlagsBits.BanMembers))return i.reply({content:'You need Ban Members permission.',ephemeral:true});
 await member.ban({reason});db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(i.guildId,i.user.id,user.id,'ban',reason);
 return i.reply({content:`Banned ${user.tag}. Reason: ${reason}`});
}
module.exports={category:'moderation',data,execute};
