'use strict';
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const OpenAI = require('openai');
const can = (i, p) => Boolean(i.memberPermissions?.has(p));
const data = new SlashCommandBuilder()
 .setName('msg').setDescription('Send a message to a channel')
 .addChannelOption(o=>o.setName('channel').setDescription('Target text channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
 .addStringOption(o=>o.setName('text').setDescription('Message to send').setRequired(true).setMaxLength(1900));
const aiMsgData = new SlashCommandBuilder().setName('ai-msg').setDescription('Generate and send an AI message')
 .addStringOption(o=>o.setName('prompt').setDescription('What the message should say').setRequired(true).setMaxLength(1500))
 .addChannelOption(o=>o.setName('channel').setDescription('Target channel; defaults to this channel').addChannelTypes(ChannelType.GuildText));
const clearData = new SlashCommandBuilder().setName('clear').setDescription('Delete recent messages')
 .addIntegerOption(o=>o.setName('amount').setDescription('Number of messages, 1–10000').setRequired(true).setMinValue(1).setMaxValue(10000))
 .addUserOption(o=>o.setName('user').setDescription('Only delete messages from this user'));
const trollData = new SlashCommandBuilder().setName('troll').setDescription('Send a harmless playful message mentioning a user')
 .addUserOption(o=>o.setName('user').setDescription('User to mention').setRequired(true));
const lockData = new SlashCommandBuilder().setName('lock').setDescription('Lock this channel, optionally exempt one user')
 .addUserOption(o=>o.setName('notfor').setDescription('User who can still send messages'));
const unlockData = new SlashCommandBuilder().setName('unlock').setDescription('Unlock this channel');
async function sendAI(prompt) {
 if(!process.env.AI_API_KEY) throw new Error('AI is not configured. Set AI_API_KEY in the hosting environment.');
 const client=new OpenAI({apiKey:process.env.AI_API_KEY,baseURL:process.env.AI_BASE_URL||'https://tokenharbor.ai/v1'});
 const r=await client.chat.completions.create({model:process.env.AI_MODEL||'deepseek-v4.1-flash:free',messages:[{role:'system',content:'Write a ready-to-send, appropriate Discord community message in the language requested by the prompt (including Hinglish or Urdu when requested). Return only the message text.'},{role:'user',content:prompt}],max_tokens:500});
 return (r.choices?.[0]?.message?.content||'').trim().slice(0,1900);
}
async function execute(i) {
 const name=i.commandName;
 if(name==='msg') {
  if(!can(i,PermissionFlagsBits.ManageMessages))return i.reply({content:'You need Manage Messages permission.',ephemeral:true});
  const channel=i.options.getChannel('channel',true), text=i.options.getString('text',true);
  await channel.send({content:text,allowedMentions:{parse:[]}});
  return i.reply({content:`Message sent to ${channel}.`,ephemeral:true});
 }
 if(name==='ai-msg') {
  if(!can(i,PermissionFlagsBits.ManageMessages))return i.reply({content:'You need Manage Messages permission.',ephemeral:true});
  await i.deferReply({ephemeral:true});
  try {const content=await sendAI(i.options.getString('prompt',true));if(!content)return i.editReply('AI returned an empty message.');const channel=i.options.getChannel('channel')||i.channel;await channel.send({content,allowedMentions:{parse:[]}});return i.editReply(`AI message sent to ${channel}.`);}
  catch(e){return i.editReply(`AI request failed: ${String(e.message||e).slice(0,300)}`);}
 }
 if(name==='clear') {
  if(!can(i,PermissionFlagsBits.ManageMessages))return i.reply({content:'You need Manage Messages permission.',ephemeral:true});
  await i.deferReply({ephemeral:true});
  const amount=i.options.getInteger('amount',true), user=i.options.getUser('user');
  try {
   let before;
   const matches = [];
   while (matches.length < amount) {
    const batch = await i.channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
    if (!batch.size) break;
    before = batch.last().id;
    for (const m of batch.values()) {
     if (m.id !== i.id && !m.pinned && (!user || m.author.id === user.id)) matches.push(m);
     if (matches.length >= amount) break;
    }
    if (batch.size < 100) break;
   }
   if (!matches.length) return i.editReply('No matching messages found.');
   let deletedCount = 0;
   const cutoff = Date.now() - 14 * 24 * 60 * 60 * 1000;
   const recent = matches.filter(m => m.createdTimestamp >= cutoff);
   const old = matches.filter(m => m.createdTimestamp < cutoff);
   for (let x = 0; x < recent.length; x += 100) {
    const group = recent.slice(x, x + 100);
    if (group.length) deletedCount += (await i.channel.bulkDelete(group, true)).size;
   }
   for (const m of old) { try { await m.delete(); deletedCount++; } catch {} }
   return i.editReply(`Deleted ${deletedCount} message(s)${user ? ` from ${user.tag}` : ''}. Pinned messages were skipped.`);
  }
  catch(e){return i.editReply(`Could not clear messages: ${String(e.message||e).slice(0,250)}`);}
 }
 if(name==='troll') {
  if(!can(i,PermissionFlagsBits.ManageMessages))return i.reply({content:'You need Manage Messages permission.',ephemeral:true});
  const user=i.options.getUser('user',true);
  if(user.id===i.user.id||user.bot)return i.reply({content:'Choose another human user.',ephemeral:true});
  await i.channel.send({content:`${user}, BusterNodes has selected you as today's chaos coordinator.`,allowedMentions:{users:[user.id]}});
  return i.reply({content:'Playful message sent.',ephemeral:true});
 }
 if(name==='lock') {
  if(!can(i,PermissionFlagsBits.ManageChannels))return i.reply({content:'You need Manage Channels permission.',ephemeral:true});
  await i.channel.permissionOverwrites.edit(i.guild.roles.everyone,{SendMessages:false,AddReactions:false});
  const user=i.options.getUser('notfor');
  if(user) await i.channel.permissionOverwrites.edit(user.id,{ViewChannel:true,SendMessages:true,AddReactions:true});
  return i.reply({content:`Channel locked${user?`; ${user.tag} is exempted`:''}.`,ephemeral:true});
 }
 if(name==='unlock') {
  if(!can(i,PermissionFlagsBits.ManageChannels))return i.reply({content:'You need Manage Channels permission.',ephemeral:true});
  await i.channel.permissionOverwrites.edit(i.guild.roles.everyone,{SendMessages:null,AddReactions:null});
  return i.reply({content:'Channel unlocked.',ephemeral:true});
 }
}
module.exports={category:'utilities',data,execute,extra:[aiMsgData,clearData,trollData,lockData,unlockData]};
