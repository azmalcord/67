'use strict';
const { SlashCommandBuilder }=require('discord.js');
const OpenAI=require('openai');
const data=new SlashCommandBuilder().setName('ai').setDescription('Ask the configured AI assistant').addStringOption(o=>o.setName('prompt').setDescription('What do you want to ask?').setRequired(true).setMaxLength(1500));
async function execute(i){
 const key=process.env.AI_API_KEY;
 if(!key)return i.reply({content:'AI is not configured yet. Set AI_API_KEY in the environment and restart the bot.',ephemeral:true});
 await i.deferReply();
 const client=new OpenAI({apiKey:key,baseURL:process.env.AI_BASE_URL||'https://tokenharbor.ai/v1'});
 const response=await client.chat.completions.create({model:process.env.AI_MODEL||'deepseek-v4.1-flash:free',messages:[{role:'system',content:'You are the BusterNodes community assistant. Be helpful and concise; reply in the language and style the user uses, including natural Hinglish and Urdu when appropriate. Do not claim to access private server data.'},{role:'user',content:i.options.getString('prompt',true)}],max_tokens:700});
 const text=response.choices?.[0]?.message?.content||'No response returned.';
 return i.editReply(text.slice(0,1900));
}
module.exports={category:'ai',data,execute};
