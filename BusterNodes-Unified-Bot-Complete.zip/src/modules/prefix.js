'use strict';
const { PermissionFlagsBits } = require('discord.js');
const OpenAI=require('openai');
const db=require('./db');
const owners=()=>String(process.env.OWNER_IDS||'').split(',').map(x=>x.trim()).filter(Boolean);
const isOwner=m=>owners().includes(m.author.id);
const isMod=m=>m.member?.permissions?.has(PermissionFlagsBits.ModerateMembers)||m.member?.permissions?.has(PermissionFlagsBits.BanMembers)||isOwner(m);
async function handlePrefixMessage(message){
 if(!message.guild||message.author.bot||!message.content.startsWith('?'))return;
 const [cmd,...args]=message.content.slice(1).trim().split(/\s+/);
 const target=message.mentions.members.first();
 const isOwnerUser=isOwner(message);
 const has=(perm)=>message.member?.permissions?.has(perm)||isOwnerUser;
 const deny=(perm)=>!has(perm);
 const help='BusterNodes commands: `?msg #channel <text>`, `?ai-msg #channel <prompt>`, `?ai <prompt>`, `?clear <1-10000> [@user]`, `?troll @user`, `?lock [notfor:@user]`, `?unlock`, `?warn`, `?timeout`, `?ban`. Slash commands: `/ticket-panel`, `/ticket-config`, `/feedback`, `/notes`, `/mod`, `/ai`.';
 if(cmd==='help')return message.reply(help);
 if(cmd==='ai'){
  const prompt=message.content.slice(4).trim();
  if(!prompt)return message.reply('Usage: `?ai <prompt>`');
  if(!process.env.AI_API_KEY)return message.reply('AI is not configured. Set AI_API_KEY in your hosting environment.');
  await message.channel.sendTyping();
  const ai=new OpenAI({apiKey:process.env.AI_API_KEY,baseURL:process.env.AI_BASE_URL||'https://tokenharbor.ai/v1'});
  const r=await ai.chat.completions.create({model:process.env.AI_MODEL||'deepseek-v4.1-flash:free',messages:[{role:'system',content:'You are the BusterNodes community assistant. Be helpful and concise; reply in the language and style the user uses, including natural Hinglish and Urdu when appropriate. Do not claim to access private server data.'},{role:'user',content:prompt}],max_tokens:600});
  return message.reply((r.choices?.[0]?.message?.content||'No response.').slice(0,1900));
 }
 if(cmd==='msg'){
  if(deny(PermissionFlagsBits.ManageMessages))return message.reply('You need Manage Messages permission.');
  const channel=message.mentions.channels.first();
  const content=args.filter(a=>!/^<#\d+>$/.test(a)).join(' ').trim();
  if(!channel||!content)return message.reply('Usage: `?msg #channel <message>`');
  if(!channel.isTextBased())return message.reply('Choose a text channel.');
  await channel.send({content:content.slice(0,1900),allowedMentions:{parse:[]}});
  return message.reply({content:`Message sent to ${channel}.`,allowedMentions:{parse:[]}});
 }
 if(cmd==='ai-msg'){
  if(deny(PermissionFlagsBits.ManageMessages))return message.reply('You need Manage Messages permission.');
  const channel=message.mentions.channels.first() || message.channel;
  const prompt=args.filter(a=>!/^<#\d+>$/.test(a)).join(' ').trim();
  if(!prompt)return message.reply('Usage: `?ai-msg <prompt>` or `?ai-msg #channel <prompt>`');
  if(!process.env.AI_API_KEY)return message.reply('AI is not configured. Set AI_API_KEY in your hosting environment.');
  const ai=new OpenAI({apiKey:process.env.AI_API_KEY,baseURL:process.env.AI_BASE_URL||'https://tokenharbor.ai/v1'});
  const r=await ai.chat.completions.create({model:process.env.AI_MODEL||'deepseek-v4.1-flash:free',messages:[{role:'system',content:'Write a ready-to-send Discord message for the BusterNodes community based on the user prompt. Return only the message text; do not add commentary.'},{role:'user',content:prompt}],max_tokens:500});
  const content=(r.choices?.[0]?.message?.content||'').trim().slice(0,1900);
  if(!content)return message.reply('AI did not return a message.');
  await channel.send({content,allowedMentions:{parse:[]}});
  return message.reply({content:`AI message sent to ${channel}.`,allowedMentions:{parse:[]}});
 }
 if(cmd==='clear'){
  if(deny(PermissionFlagsBits.ManageMessages))return message.reply('You need Manage Messages permission.');
  const amount=Number(args[0]);
  if(!Number.isInteger(amount)||amount<1||amount>10000)return message.reply('Usage: `?clear <1-10000> [@user]`');
  const filterUser=message.mentions.users.first();
  const status=await message.reply(`Searching for up to ${amount} matching messages...`);
  const matches=[];
  let before;
  while(matches.length<amount){
   const batch=await message.channel.messages.fetch({limit:100,...(before?{before}:{})});
   if(!batch.size)break;
   before=batch.last().id;
   for(const m of batch.values()){
    if(m.id!==message.id&&!m.pinned&&(!filterUser||m.author.id===filterUser.id))matches.push(m);
    if(matches.length>=amount)break;
   }
   if(batch.size<100)break;
  }
  if(!matches.length){await status.edit('No matching messages found.');setTimeout(()=>status.delete().catch(()=>{}),5000);return;}
  let deletedCount=0;
  const cutoff=Date.now()-14*24*60*60*1000;
  const recent=matches.filter(m=>m.createdTimestamp>=cutoff);
  const old=matches.filter(m=>m.createdTimestamp<cutoff);
  for(let x=0;x<recent.length;x+=100){
   const group=recent.slice(x,x+100);
   if(group.length)deletedCount+=(await message.channel.bulkDelete(group,true)).size;
  }
  for(const m of old){try{await m.delete();deletedCount++;}catch{}}
  await status.edit(`Cleared ${deletedCount} message(s)${filterUser?` from ${filterUser.tag}`:''}. Pinned messages were skipped.`);
  setTimeout(()=>status.delete().catch(()=>{}),8000);
  return;
 }
 if(cmd==='troll'){
  if(deny(PermissionFlagsBits.ManageMessages))return message.reply('You need Manage Messages permission.');
  if(!target)return message.reply('Usage: `?troll @user`');
  if(target.id===message.author.id||target.user.bot)return message.reply('Choose another human member.');
  return message.channel.send({content:`${target}, BusterNodes has selected you for absolutely no reason. You have been officially nominated as today's chaos coordinator.`,allowedMentions:{users:[target.id]}});
 }
 if(cmd==='lock'){
  if(deny(PermissionFlagsBits.ManageChannels))return message.reply('You need Manage Channels permission.');
  const everyone=message.guild.roles.everyone;
  const exempt=message.mentions.members.first();
  await message.channel.permissionOverwrites.edit(everyone,{SendMessages:false,AddReactions:false});
  if(exempt) await message.channel.permissionOverwrites.edit(exempt.id,{ViewChannel:true,SendMessages:true,AddReactions:true});
  return message.channel.send({content:`🔒 Channel locked by ${message.author}.${exempt?` ${exempt} is exempted from the lock.`:''}`,allowedMentions:{parse:[]}});
 }
 if(cmd==='unlock'){
  if(deny(PermissionFlagsBits.ManageChannels))return message.reply('You need Manage Channels permission.');
  await message.channel.permissionOverwrites.edit(message.guild.roles.everyone,{SendMessages:null,AddReactions:null});
  return message.channel.send('🔓 Channel unlocked.');
 }
 if(!['warn','timeout','ban'].includes(cmd))return;
 if(!isMod(message))return message.reply('You need moderation permissions to use this command.');
 if(!target)return message.reply(`Usage: \`?${cmd} @member ${cmd==='timeout'?'minutes ':''}<reason>\``);
 if(target.id===message.author.id||target.id===message.client.user.id)return message.reply('You cannot moderate yourself or the bot.');
 if(cmd==='warn'){
  const why=args.slice(1).join(' ')||'No reason provided';
  db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(message.guild.id,message.author.id,target.id,'warn',why);
  await target.send(`You were warned in ${message.guild.name}. Reason: ${why}`).catch(()=>{});
  return message.reply(`Warned ${target.user.tag}. Reason: ${why}`);
 }
 if(cmd==='timeout'){
  if(!has(PermissionFlagsBits.ModerateMembers))return message.reply('You need Moderate Members permission.');
  const minutes=Number(args[1]); if(!Number.isInteger(minutes)||minutes<1||minutes>40320)return message.reply('Usage: `?timeout @member <minutes> <reason>` (1–40320 minutes).');
  const why=args.slice(2).join(' ')||'No reason provided';await target.timeout(minutes*60000,why);
  db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(message.guild.id,message.author.id,target.id,'timeout',`${minutes}m: ${why}`);
  return message.reply(`Timed out ${target.user.tag} for ${minutes} minutes.`);
 }
 if(!has(PermissionFlagsBits.BanMembers))return message.reply('You need Ban Members permission.');
 const why=args.slice(1).join(' ')||'No reason provided';await target.ban({reason:why});
 db.prepare('INSERT INTO modlogs(guild_id,moderator_id,target_id,action,reason) VALUES(?,?,?,?,?)').run(message.guild.id,message.author.id,target.id,'ban',why);
 return message.reply(`Banned ${target.user.tag}.`);
}
module.exports={handlePrefixMessage};
