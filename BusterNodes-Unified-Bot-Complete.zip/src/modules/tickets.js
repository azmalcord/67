'use strict';
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ChannelType, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const db = require('./db');
const config = require('../config');
const DEFAULT_CATEGORIES = [['billing','Billing'],['support','Support'],['technical','Technical Help'],['abuse','Abuse Report'],['partnership','Partnership']];
function categoriesFor(guildId) {
 const row = db.prepare("SELECT value FROM settings WHERE guild_id=? AND key='ticket_categories'").get(guildId);
 if (row) { try { const parsed=JSON.parse(row.value); if(Array.isArray(parsed)&&parsed.length) return parsed; } catch {} }
 return DEFAULT_CATEGORIES;
}
const data = new SlashCommandBuilder().setName('ticket-panel').setDescription('Post the support ticket panel').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild);
const configData = new SlashCommandBuilder().setName('ticket-config').setDescription('Configure ticket categories').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
 .addSubcommand(s=>s.setName('list').setDescription('List ticket categories'))
 .addSubcommand(s=>s.setName('add').setDescription('Add a category').addStringOption(o=>o.setName('key').setDescription('Short key, e.g. billing').setRequired(true)).addStringOption(o=>o.setName('label').setDescription('Button label').setRequired(true)))
 .addSubcommand(s=>s.setName('remove').setDescription('Remove a category').addStringOption(o=>o.setName('key').setDescription('Category key').setRequired(true)));
async function execute(interaction) {
 const embed = new EmbedBuilder().setColor(config.bot.color).setTitle('BusterNodes Support Center')
 .setDescription('Need help with VPS, hosting, billing or technical issues? Choose a category below and explain the issue clearly. Staff will respond in your private ticket.')
 .setFooter({text:'BusterNodes Support'});
 if(process.env.TICKET_PANEL_IMAGE_URL) embed.setImage(process.env.TICKET_PANEL_IMAGE_URL);
 const cats=categoriesFor(interaction.guildId), rows=[];
 for(let i=0;i<cats.length;i+=5) rows.push(new ActionRowBuilder().addComponents(...cats.slice(i,i+5).map(([key,label])=>new ButtonBuilder().setCustomId('bn_ticket:'+key).setLabel(String(label).slice(0,80)).setStyle(key==='billing'?ButtonStyle.Primary:ButtonStyle.Secondary))));
 await interaction.channel.send({embeds:[embed],components:rows});
 return interaction.reply({content:'Ticket panel posted.',ephemeral:true});
}
async function createTicket(interaction,key) {
 const category=categoriesFor(interaction.guildId).find(c=>c[0]===key); if(!category) return interaction.reply({content:'Unknown ticket category.',ephemeral:true});
 const existing=db.prepare("SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=? AND status='open'").get(interaction.guildId,interaction.user.id);
 if(existing) return interaction.reply({content:`You already have an open ticket: <#${existing.channel_id}>`,ephemeral:true});
 const parent=process.env.TICKET_CATEGORY_ID||undefined;
 const safeName=interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,18)||'user';
 const modRole=process.env.TICKET_STAFF_ROLE_ID;
 const overwrites=[{id:interaction.guild.roles.everyone.id,deny:[PermissionFlagsBits.ViewChannel]},{id:interaction.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.AttachFiles]},{id:interaction.client.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ReadMessageHistory]}];
 if(modRole) overwrites.push({id:modRole,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.ManageMessages]});
 const channel=await interaction.guild.channels.create({name:`ticket-${safeName}`,type:ChannelType.GuildText,parent,permissionOverwrites:overwrites});
 db.prepare('INSERT INTO tickets(guild_id,channel_id,user_id,category) VALUES(?,?,?,?)').run(interaction.guildId,channel.id,interaction.user.id,category[1]);
 const embed=new EmbedBuilder().setColor(0x7b2437).setTitle(`Ticket: ${category[1]}`).setDescription(`Hello ${interaction.user}, please describe your issue clearly. A staff member will assist you.`).setTimestamp();
 const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('bn_ticket_close').setLabel('Close ticket').setStyle(ButtonStyle.Danger));
 await channel.send({content:`${interaction.user}${modRole?` <@&${modRole}>`:''}`,embeds:[embed],components:[row],allowedMentions:{users:[interaction.user.id],roles:modRole?[modRole]:[]}});
 return interaction.reply({content:`Ticket created: ${channel}`,ephemeral:true});
}
async function closeTicket(interaction) {
 const ticket=db.prepare("SELECT * FROM tickets WHERE channel_id=? AND status='open'").get(interaction.channelId);
 if(!ticket) return interaction.reply({content:'This channel is not an open ticket.',ephemeral:true});
 const canClose=ticket.user_id===interaction.user.id||interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)||Boolean(process.env.TICKET_STAFF_ROLE_ID&&interaction.member?.roles?.cache?.has(process.env.TICKET_STAFF_ROLE_ID));
 if(!canClose) return interaction.reply({content:'Only the ticket creator or staff can close this ticket.',ephemeral:true});
 db.prepare("UPDATE tickets SET status='closed' WHERE channel_id=?").run(interaction.channelId);
 await interaction.reply({content:'Ticket closed. This channel will be deleted in 5 seconds.'});
 setTimeout(()=>interaction.channel.delete('Ticket closed').catch(()=>{}),5000);
}
async function configExecute(interaction) {
 const sub=interaction.options.getSubcommand(); let cats=categoriesFor(interaction.guildId).map(c=>[...c]);
 if(sub==='list') return interaction.reply({content:cats.map(([key,label])=>`\`${key}\` — ${label}`).join('\n')||'No categories configured.',ephemeral:true});
 const key=interaction.options.getString('key',true).toLowerCase().replace(/[^a-z0-9_-]/g,'').slice(0,20);
 if(!key) return interaction.reply({content:'Use a valid category key.',ephemeral:true});
 if(sub==='add') {const label=interaction.options.getString('label',true).trim().slice(0,80); if(cats.some(c=>c[0]===key)) return interaction.reply({content:'That key already exists.',ephemeral:true}); if(cats.length>=25)return interaction.reply({content:'Maximum 25 categories reached.',ephemeral:true}); cats.push([key,label]);}
 else {cats=cats.filter(c=>c[0]!==key); if(!cats.length)return interaction.reply({content:'Keep at least one category.',ephemeral:true});}
 db.prepare("INSERT INTO settings(guild_id,key,value) VALUES(?, 'ticket_categories', ?) ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value").run(interaction.guildId,JSON.stringify(cats));
 return interaction.reply({content:sub==='add'?`Added ${key}. Repost with /ticket-panel.`:`Removed ${key}. Existing tickets remain unchanged.`,ephemeral:true});
}
module.exports={category:'ticket',data,execute,configData,configExecute,categories:DEFAULT_CATEGORIES,categoriesFor,createTicket,closeTicket};
